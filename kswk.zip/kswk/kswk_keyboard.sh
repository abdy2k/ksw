# /usr/bin/env bash 

# Check if binary exists and is executable
TARGET="/opt/kswk/kswk"

if [ -x "$TARGET" ]; then
    nohup "$TARGET" >/dev/null 2>&1 &
    disown
else
    echo "Executable not found at $TARGET" >&2
    exit 1
fi
